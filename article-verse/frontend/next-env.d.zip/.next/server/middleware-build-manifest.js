globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/wvSJWp05Vk9Ho-V-2jSdp/_buildManifest.js",
    "static/wvSJWp05Vk9Ho-V-2jSdp/_ssgManifest.js",
    "static/wvSJWp05Vk9Ho-V-2jSdp/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/0p5.qr0b94vxo.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/turbopack-0agkdb7tv-786.js"
  ]
};
