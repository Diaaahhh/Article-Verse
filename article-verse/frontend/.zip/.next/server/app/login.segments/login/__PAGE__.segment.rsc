1:"$Sreact.fragment"
2:I[81795,["/_next/static/chunks/0lhl.4u1vmb3f.js","/_next/static/chunks/0dbhjjzl8qfwv.js","/_next/static/chunks/15c5mp02xwuz_.js"],"default"]
3:I[97367,["/_next/static/chunks/0lhl.4u1vmb3f.js","/_next/static/chunks/0dbhjjzl8qfwv.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/15c5mp02xwuz_.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jthLrxx_scvngJ4poQ7WZ"}
5:null
