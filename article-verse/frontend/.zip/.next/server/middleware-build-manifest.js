globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/jthLrxx_scvngJ4poQ7WZ/_buildManifest.js",
    "static/jthLrxx_scvngJ4poQ7WZ/_ssgManifest.js",
    "static/jthLrxx_scvngJ4poQ7WZ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/05sqh99f1_wo7.js",
    "static/chunks/turbopack-05mb0p3kq_jlm.js"
  ]
};
