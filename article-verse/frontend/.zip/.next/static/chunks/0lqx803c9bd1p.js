(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,5766,e=>{"use strict";let t,a;var r,s=e.i(71645);let i={data:""},o=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,n=/\n+/g,d=(e,t)=>{let a="",r="",s="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+o+";":r+="f"==i[1]?d(o,i):i+"{"+d(o,"k"==i[1]?"":t)+"}":"object"==typeof o?r+=d(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=d.p?d.p(i,o):i+":"+o+";")}return a+(t&&s?t+"{"+s+"}":s)+r},c={},u=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+u(e[a]);return t}return e};function p(e){let t,a,r=this||{},s=e.call?e(r.p):e;return((e,t,a,r,s)=>{var i;let p=u(e),m=c[p]||(c[p]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(p));if(!c[m]){let t=p!==e?e:(e=>{let t,a,r=[{}];for(;t=o.exec(e.replace(l,""));)t[4]?r.shift():t[3]?(a=t[3].replace(n," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(n," ").trim();return r[0]})(e);c[m]=d(s?{["@keyframes "+m]:t}:t,a?"":"."+m)}let f=a&&c.g?c.g:null;return a&&(c.g=c[m]),i=c[m],f?t.data=t.data.replace(f,i):-1===t.data.indexOf(i)&&(t.data=r?i+t.data:t.data+i),m})(s.unshift?s.raw?(t=[].slice.call(arguments,1),a=r.p,s.reduce((e,r,s)=>{let i=t[s];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"")):s.reduce((e,t)=>Object.assign(e,t&&t.call?t(r.p):t),{}):s,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i})(r.target),r.g,r.o,r.k)}p.bind({g:1});let m,f,h,g=p.bind({k:1});function b(e,t){let a=this||{};return function(){let r=arguments;function s(i,o){let l=Object.assign({},i),n=l.className||s.className;a.p=Object.assign({theme:f&&f()},l),a.o=/ *go\d+/.test(n),l.className=p.apply(a,r)+(n?" "+n:""),t&&(l.ref=o);let d=e;return e[0]&&(d=l.as||e,delete l.as),h&&d[0]&&h(l),m(d,l)}return t?t(s):s}}var y=(e,t)=>"function"==typeof e?e(t):e,x=(t=0,()=>(++t).toString()),v=()=>{if(void 0===a&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");a=!e||e.matches}return a},w="default",j=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return j(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},N=[],E={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},k={},C=(e,t=w)=>{k[t]=j(k[t]||E,e),N.forEach(([e,a])=>{e===t&&a(k[t])})},S=e=>Object.keys(k).forEach(t=>C(e,t)),$=(e=w)=>t=>{C(t,e)},A={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},O=e=>(t,a)=>{let r,s=((e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||x()}))(t,e,a);return $(s.toasterId||(r=s.id,Object.keys(k).find(e=>k[e].toasts.some(e=>e.id===r))))({type:2,toast:s}),s.id},D=(e,t)=>O("blank")(e,t);D.error=O("error"),D.success=O("success"),D.loading=O("loading"),D.custom=O("custom"),D.dismiss=(e,t)=>{let a={type:3,toastId:e};t?$(t)(a):S(a)},D.dismissAll=e=>D.dismiss(void 0,e),D.remove=(e,t)=>{let a={type:4,toastId:e};t?$(t)(a):S(a)},D.removeAll=e=>D.remove(void 0,e),D.promise=(e,t,a)=>{let r=D.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?y(t.success,e):void 0;return s?D.success(s,{id:r,...a,...null==a?void 0:a.success}):D.dismiss(r),e}).catch(e=>{let s=t.error?y(t.error,e):void 0;s?D.error(s,{id:r,...a,...null==a?void 0:a.error}):D.dismiss(r)}),e};var T=1e3,P=g`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,I=g`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,M=g`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,L=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${P} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${I} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${M} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,_=g`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,z=b("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${_} 1s linear infinite;
`,R=g`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,U=g`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,F=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${R} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${U} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,B=b("div")`
  position: absolute;
`,H=b("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,K=g`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,q=b("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${K} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,G=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?s.createElement(q,null,t):t:"blank"===a?null:s.createElement(H,null,s.createElement(z,{...r}),"loading"!==a&&s.createElement(B,null,"error"===a?s.createElement(L,{...r}):s.createElement(F,{...r})))},J=b("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,W=b("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Y=s.memo(({toast:e,position:t,style:a,children:r})=>{let i=e.height?((e,t)=>{let a=e.includes("top")?1:-1,[r,s]=v()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*a}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*a}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${g(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${g(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},o=s.createElement(G,{toast:e}),l=s.createElement(W,{...e.ariaProps},y(e.message,e));return s.createElement(J,{className:e.className,style:{...i,...a,...e.style}},"function"==typeof r?r({icon:o,message:l}):s.createElement(s.Fragment,null,o,l))});r=s.createElement,d.p=void 0,m=r,f=void 0,h=void 0;var Z=({id:e,className:t,style:a,onHeightUpdate:r,children:i})=>{let o=s.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return s.createElement("div",{ref:o,className:t,style:a},i)},Q=p`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;e.s(["Toaster",0,({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:i,toasterId:o,containerStyle:l,containerClassName:n})=>{let{toasts:d,handlers:c}=((e,t="default")=>{let{toasts:a,pausedAt:r}=((e={},t=w)=>{let[a,r]=(0,s.useState)(k[t]||E),i=(0,s.useRef)(k[t]);(0,s.useEffect)(()=>(i.current!==k[t]&&r(k[t]),N.push([t,r]),()=>{let e=N.findIndex(([e])=>e===t);e>-1&&N.splice(e,1)}),[t]);let o=a.toasts.map(t=>{var a,r,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||A[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...a,toasts:o}})(e,t),i=(0,s.useRef)(new Map).current,o=(0,s.useCallback)((e,t=T)=>{if(i.has(e))return;let a=setTimeout(()=>{i.delete(e),l({type:4,toastId:e})},t);i.set(e,a)},[]);(0,s.useEffect)(()=>{if(r)return;let e=Date.now(),s=a.map(a=>{if(a.duration===1/0)return;let r=(a.duration||0)+a.pauseDuration-(e-a.createdAt);if(r<0){a.visible&&D.dismiss(a.id);return}return setTimeout(()=>D.dismiss(a.id,t),r)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[a,r,t]);let l=(0,s.useCallback)($(t),[t]),n=(0,s.useCallback)(()=>{l({type:5,time:Date.now()})},[l]),d=(0,s.useCallback)((e,t)=>{l({type:1,toast:{id:e,height:t}})},[l]),c=(0,s.useCallback)(()=>{r&&l({type:6,time:Date.now()})},[r,l]),u=(0,s.useCallback)((e,t)=>{let{reverseOrder:r=!1,gutter:s=8,defaultPosition:i}=t||{},o=a.filter(t=>(t.position||i)===(e.position||i)&&t.height),l=o.findIndex(t=>t.id===e.id),n=o.filter((e,t)=>t<l&&e.visible).length;return o.filter(e=>e.visible).slice(...r?[n+1]:[0,n]).reduce((e,t)=>e+(t.height||0)+s,0)},[a]);return(0,s.useEffect)(()=>{a.forEach(e=>{if(e.dismissed)o(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[a,o]),{toasts:a,handlers:{updateHeight:d,startPause:n,endPause:c,calculateOffset:u}}})(a,o);return s.createElement("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...l},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(a=>{let o,l,n=a.position||t,d=c.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}),u=(o=n.includes("top"),l=n.includes("center")?{justifyContent:"center"}:n.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:v()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${d*(o?1:-1)}px)`,...o?{top:0}:{bottom:0},...l});return s.createElement(Z,{id:a.id,key:a.id,onHeightUpdate:c.updateHeight,className:a.visible?Q:"",style:u},"custom"===a.type?y(a.message,a):i?i(a):s.createElement(Y,{toast:a,position:n}))}))},"default",0,D],5766)},56306,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(18566),s=e.i(46925),i=e.i(5766);function o(){let[e,r]=(0,a.useState)([]),[o,l]=(0,a.useState)(""),[n,d]=(0,a.useState)(""),[c,u]=(0,a.useState)(""),[p,m]=(0,a.useState)(""),[f,h]=(0,a.useState)(""),[g,b]=(0,a.useState)(""),y=async()=>{try{let t=await fetch(`${s.API_BASE_URL}/api/add-post`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:n,subtitle:c,content:p,metaTitle:f,metaDesc:g,metaKeywords:e}),credentials:"include"}),a=await t.json();201===t.status?(i.default.success("Post submitted for review 🚀"),d(""),u(""),m(""),h(""),b(""),r([])):i.default.error(a.message||"Failed to submit")}catch(e){console.log(e),i.default.error("Server error")}},x="w-full px-3 py-2 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all",v="block text-sm font-semibold text-gray-700 mb-1";return(0,t.jsx)("div",{className:"flex justify-center  min-h-screen w-full p-6",children:(0,t.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-10 gap-8 max-w-7xl w-full",children:[(0,t.jsxs)("div",{className:"lg:col-span-7 bg-white p-8 rounded-lg shadow-sm border border-gray-200",children:[(0,t.jsx)("h1",{className:"text-xl font-bold text-gray-900 mb-6 text-center ",children:"Add Post"}),(0,t.jsxs)("form",{className:"space-y-4",onSubmit:e=>e.preventDefault(),children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:v,children:"Title"}),(0,t.jsx)("input",{type:"text",className:x,placeholder:"Enter title",value:n,onChange:e=>d(e.target.value)})]}),(0,t.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:v,children:"Subtitle"}),(0,t.jsx)("input",{type:"text",className:x,placeholder:"Enter subtitle",value:c,onChange:e=>u(e.target.value)})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:v,children:"Meta Title"}),(0,t.jsx)("input",{type:"text",maxLength:60,className:x,placeholder:"Max 60 chars",value:f,onChange:e=>h(e.target.value)})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:v,children:"Text Content"}),(0,t.jsx)("textarea",{rows:6,className:x,placeholder:"Write your content...",value:p,onChange:e=>m(e.target.value)})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:v,children:"Meta Description"}),(0,t.jsx)("textarea",{maxLength:160,rows:2,className:x,placeholder:"Max 160 chars",value:g,onChange:e=>b(e.target.value)})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:v,children:"Meta Keywords"}),(0,t.jsxs)("div",{className:"min-h-[42px] flex flex-wrap gap-2 p-2 border border-gray-300 rounded focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition-all",children:[e.map((a,s)=>(0,t.jsxs)("span",{className:"bg-gray-100 text-gray-700 px-2 py-1 rounded text-sm flex items-center border border-gray-200",children:[a," ",(0,t.jsx)("button",{onClick:()=>{r(e.filter((e,t)=>t!==s))},className:"ml-2 text-gray-400 hover:text-red-500",children:"×"})]},s)),(0,t.jsx)("input",{value:o,onChange:e=>l(e.target.value),onKeyDown:t=>{if(","===t.key||"Enter"===t.key){t.preventDefault();let a=o.trim().replace(/,/g,"");a&&e.length<10&&!e.includes(a)&&(r([...e,a]),l(""))}},className:"flex-1 outline-none text-sm px-1",placeholder:"Type and press comma..."})]})]}),(0,t.jsx)("div",{className:"pt-4 flex justify-center",style:{marginTop:"5px"},children:(0,t.jsx)("button",{type:"button",onClick:y,className:"w-64 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded shadow-sm transition-all",children:"Submit"})})]})]}),(0,t.jsxs)("div",{className:"lg:col-span-3 space-y-6",children:[(0,t.jsxs)("div",{className:"p-6 bg-white border border-gray-200 rounded-lg shadow-sm",children:[(0,t.jsx)("h3",{className:"font-bold text-gray-900 mb-2",children:"Upgrade to Pro"}),(0,t.jsx)("p",{className:"text-gray-500 text-sm mb-4",children:"Get access to advanced SEO tools and analytics."}),(0,t.jsx)("button",{className:"w-full py-2 border border-blue-600 text-blue-600 font-medium rounded hover:bg-blue-50 transition-all",children:"Learn More"})]}),(0,t.jsxs)("div",{className:"p-6 bg-white border border-gray-200 rounded-lg shadow-sm",children:[(0,t.jsx)("h3",{className:"font-bold text-gray-900 mb-4",children:"Sponsored"}),(0,t.jsx)("div",{className:"h-40 bg-gray-50 rounded flex items-center justify-center text-gray-400 border border-dashed border-gray-300",children:"Ad Space"})]})]})]})})}e.s(["default",0,function(){let e=(0,r.useRouter)();return(0,a.useEffect)(()=>{(async()=>{401===(await fetch(`${s.API_BASE_URL}/api/check-auth`,{credentials:"include"})).status&&e.push("/login")})()},[e]),(0,t.jsx)(o,{})}],56306)}]);